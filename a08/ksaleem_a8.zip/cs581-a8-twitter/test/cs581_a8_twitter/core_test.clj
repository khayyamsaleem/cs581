(ns cs581-a8-twitter.core-test
  (:require [clojure.test :refer :all]
            [cs581-a8-twitter.core :refer :all]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
